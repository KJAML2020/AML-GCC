import React, { Component } from "react";
import agent from "./../../services/agent";
import { Carousel as NCarousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

import ImageConstant from "utils/imageConstants";

import styles from "./home.module.scss";

export default class Carousel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mounted: false,
      mobileBannerArray: null,
    };
  }

  fetchMobileBanners = () => {
    agent.User.getMobileBanner().then((response) => {
      console.log(response);
      if (response.data.success == true) {
        this.setState({
          mobileBannerArray: response.data.result.result,
        });
      } else {
        this.setState({
          mobileBannerArray: [],
        });
      }
    });
  };

  componentDidMount() {
    this.fetchMobileBanners();
    this.handleMount(true);
  }
  componentWillUnmount() {
    this.handleMount(false);
  }

  handleMount = (flag) => this.setState({ mounted: flag });

  renderFallbackBaner = () => (
    <NCarousel
      autoPlay
      showArrows={false}
      showStatus={false}
      showThumbs={false}
      stopOnHover={false}
      infiniteLoop={true}
      transitionTime={800}
      interval={3000}
    >
      <div>
        <img
          src={ImageConstant.LANDING_ONE_ICON}
          className={styles.imageStyle}
          alt="landing"
        />
      </div>
      <div>
        <img
          src={ImageConstant.LANDING_TWO_ICON}
          className={styles.imageStyle}
          alt="landing"
        />
      </div>
    </NCarousel>
  );

  render() {
    const { bannerPayload } = this.props;
    let bannerMobileArray = [];
    if (
      this.state.mobileBannerArray != null &&
      this.state.mobileBannerArray.length != 0
    ) {
      this.state.mobileBannerArray.forEach((banner, index) => {
        bannerMobileArray.push(banner.promotional_banner);
      });
    }
    console.log(bannerMobileArray);
    // let bannerMobileArray = [
    //   "https://firebasestorage.googleapis.com/v0/b/youngenginer-1c1ab.appspot.com/o/banner%2Fmb1.png?alt=media&token=8f97561f-0dd6-46ce-8f1b-5f1d9732c83d",
    //   "https://firebasestorage.googleapis.com/v0/b/youngenginer-1c1ab.appspot.com/o/banner%2Fmb2.png?alt=media&token=168006fc-6d71-4223-8e91-fea2c6e9244c",
    //   "https://firebasestorage.googleapis.com/v0/b/youngenginer-1c1ab.appspot.com/o/banner%2Fmb3.png?alt=media&token=648e23ee-3246-46c2-bbcb-98aaa55f6ef9",
    //   "https://firebasestorage.googleapis.com/v0/b/youngenginer-1c1ab.appspot.com/o/banner%2Fmb4.png?alt=media&token=9f4cc07a-577c-47ff-81de-d6202922faf2",
    // ];

    const screenWidth = window.screen.width;
    let deviceType = 0;
    if (parseInt(screenWidth) <= 424) {
      deviceType = 1;
    } else {
      deviceType = 0;
    }
    return (
      <>
        {this.state.mounted && (
          <div className={styles.carouselMainContainer}>
            {/* <div className={styles.carouselTextContainer}>
              <h1>Best Quality Food Delivery With All Safety Checks</h1>
            </div> */}
            <div className={styles.carouselMainContainer}>
              {bannerPayload ? (
                <NCarousel
                  autoPlay
                  showArrows={false}
                  showStatus={false}
                  showThumbs={false}
                  stopOnHover={false}
                  infiniteLoop={true}
                  transitionTime={800}
                  interval={3000}
                >
                  {deviceType == 0
                    ? bannerPayload.map((banner, index) => (
                        <div key={index}>
                          <img
                            src={banner}
                            className={styles.imageStyle}
                            alt="landing"
                          />
                        </div>
                      ))
                    : bannerMobileArray.map((banner, index) => (
                        <div key={index}>
                          <img
                            src={banner}
                            className={styles.imageStyle}
                            alt="landing"
                          />
                        </div>
                      ))}
                </NCarousel>
              ) : (
                this.renderFallbackBaner()
              )}
            </div>
          </div>
        )}
      </>
    );
  }
}
