const FACEBOOK_LINK = "https://www.facebook.com/";
const INSTAGRAM_LINK = "https://www.instagram.com/";
const TWITTER_LINK = "https://www.twitter.com/";

export default {
  FACEBOOK_LINK,
  INSTAGRAM_LINK,
  TWITTER_LINK,
};
