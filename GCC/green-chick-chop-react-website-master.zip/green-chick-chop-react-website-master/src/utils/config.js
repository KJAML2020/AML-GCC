export default {
  AUTH_TOKEN: "authToken",
  VENDOR_ID: "id",
  MAP_API_KEY: "AIzaSyDfFUdxR8Y7F5Skq4Sae4QkEAkuBSvlsD0",
  USER_DETAIL: "user",
};
