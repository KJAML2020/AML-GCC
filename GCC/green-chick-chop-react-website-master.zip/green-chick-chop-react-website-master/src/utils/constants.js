export default {
  ERROR_MESSAGE: "Something Went Wrong!! Please try again.",
  LOCAL_STORAGE_KEY: "state",
  BEST_SELLING_FILTER_CONSTANT: "bestselling",
};
